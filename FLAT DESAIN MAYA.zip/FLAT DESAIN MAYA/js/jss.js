</body>
</html>
<section class="main">
    <div class="container">
      <div class="main-content">
        <div class="text">
          <h1>
            ingat!satu-satunya hal yang dapat merubah takdir yang digariskan oleh Tuhan adalah doa yang tulus <br />
            tapi jikapun tidak, maka doa tersebut akan memberikanmu kelapangan hati,sehingga kamu mampu untuk bangkit.
          </p>
            </div>
            </section>
        </p>
            <section class="page two">
                <div class="page-container">
                    <!-- konten disini -->
                    <h2>cerita</h2>
            <p>Pagi itu hujan turun dengan deras. Ani merasa bingung bagaimana untuk berangkat ke sekolah. Ketika sedang memandang hujan, terdengar suara HP berdering dari kamar Ani, lantas saja Ani masuk ke kamar dan menjawab telepon.

                Ternyata yang menghubungi Ani adalah Lia sahabatnya. Dalam teleponnya Lia mengatakan bahwa ia akan menjemput Ani, sebab Lia tahu jika Ani sedang kebingungan bagaimana untuk pergi ke sekolah.
                
                Tak selang berapa lama, Lia sudah sampai di depan rumah Ani bersama ayahnya menggunakan mobil. Ani pun bergegas berpamitan pada orang tuannya dan keluar untuk menemui Lia.
                
                Setelah sampai di sekolah, yang merupakan teman sebangku tersebut pun masuk menuju kelasnya. Istirahat pun tiba, keduanya pergi ke kantin untuk menghilangkan rasa lapar. Ketika hendak membayar ternyata Lia lupa membawa dompet. Sehingga Ani sang sahabat membayarkannya.
            </section>
                </div>
            </section>
        <script type="text/javascript" src="http://code.jqueery-1.9.1.js"></script>
        <script type="text/javascript" src="http://code.jqueery.onepage-scroll.js"></script>
        <script type="text/javascript">
        ${".main"}.onepage_scroll{{
            sectionContainer: "section"
            easing:" cubic-bezier(0.180, 0.900, 0.410, 1.210}"
        }};
        </script>
    </body>
    </html>
